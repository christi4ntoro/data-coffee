var manifest_route = [
	// Course
	"images/m1/m110-bg.png",
	"images/m1/m101e.png",
	"images/m1/m106-plano.svg",
	"images/m1/m121-bg.png",
	"images/m1/m103-bg.png",
	"images/m1/m109a-drag.svg",
	"images/m1/m109b-drag.svg",
	"images/m1/m109c-drag.svg",
	"images/m1/m109d-drag.svg",
	"images/m1/m109e-drag.svg",
	"images/m1/m109f-drag.svg",
	"images/m1/m109g-drag.svg",
	"images/m1/m109h-drag.svg",
	"images/m1/m106a.svg",
	"images/m1/m106b.svg",
	"images/m1/m106c.svg",
	"images/m1/m106d.svg",
	"images/m1/m106e.svg",
	"images/m1/m106f.svg",
	"images/m1/m106g.svg"
];