var jsonCourse = {
   "title":"<b>GEB: EYC · M I ·</b>",
   "subtitle":"",
   "goals":[
      {
         "name":"Misión 1",
         "mission":"Micro SD",
         "code":"EC01",
         "theme":"theme01"
      }
   ],
   "modules":[
      {
         "title":"Misión 1",
         "code":"m1",
         "submodules":[
            {
               "title":"Fundamentos del programa de Ética y Cumplimiento del GEB",
               "code":"m1_06",
               "template":"m1/m1_06",
               "goals": "EC01"
            }
         ]
      }
   ]
};